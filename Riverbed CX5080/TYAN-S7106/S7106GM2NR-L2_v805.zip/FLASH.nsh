## flash BIOS
afuefix64.efi 7106V805.ROM /b /n /p /r1 /r2 /l /k /me /RLC:F





